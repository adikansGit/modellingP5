clear all, close all;

k1 = 4.6656;
k2 = -0.1557;
k3 = 0.1547;
I_now = 603.1;
I_ref = 397;
Fbm = 2.76;


A = [100 200];

Cp = (I_now*10.^(k1 + (k2*log10(A)) + (k3*(log10(A)).^2)))/I_ref;

n = 30;
i = 0.08;

tau_i = (i*(1+i)^n)/((1+i)^n - 1);

Cp_annual = Fbm*Cp*i;

cinv2 = (Cp_annual(2) - Cp_annual(1))/(A(2) - A(1));
cinv1 = Cp_annual(1) - (cinv2*A(1));